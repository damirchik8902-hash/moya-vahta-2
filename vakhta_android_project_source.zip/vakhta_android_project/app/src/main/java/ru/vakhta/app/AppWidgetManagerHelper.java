package ru.vakhta.app;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
public final class AppWidgetManagerHelper {
 public static void refresh(Context context) { AppWidgetManager m=AppWidgetManager.getInstance(context); int[] ids=m.getAppWidgetIds(new ComponentName(context, VakhtaWidgetProvider.class)); for(int id:ids) VakhtaWidgetProvider.update(context,m,id); }
}
