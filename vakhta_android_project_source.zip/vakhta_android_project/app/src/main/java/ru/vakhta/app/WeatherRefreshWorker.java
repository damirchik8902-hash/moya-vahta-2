package ru.vakhta.app;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Refreshes the compact weather cached for the home-screen widget while the app is closed. */
public class WeatherRefreshWorker extends Worker {
    private static final String UNIQUE_NOW = "vakhta-weather-refresh-now";
    private static final String UNIQUE_PERIODIC = "vakhta-weather-refresh-periodic";

    public WeatherRefreshWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    public static void schedule(Context context) {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        WorkManager manager = WorkManager.getInstance(context.getApplicationContext());
        OneTimeWorkRequest now = new OneTimeWorkRequest.Builder(WeatherRefreshWorker.class)
                .setConstraints(constraints)
                .build();
        manager.enqueueUniqueWork(UNIQUE_NOW, ExistingWorkPolicy.KEEP, now);
        PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(WeatherRefreshWorker.class, 30, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build();
        manager.enqueueUniquePeriodicWork(UNIQUE_PERIODIC, ExistingPeriodicWorkPolicy.KEEP, periodic);
    }

    @Override public Result doWork() {
        Context context = getApplicationContext();
        SharedPreferences prefs = context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        JSONObject cached;
        try { cached = new JSONObject(prefs.getString("weather_json", "{}")); }
        catch (Exception e) { cached = new JSONObject(); }
        try {
            cached.put("work", fetch(61.6412, 147.8029));
            cached.put("home", fetch(41.0167, 70.1436));
            prefs.edit().putString("weather_json", cached.toString()).apply();
            AppWidgetManagerHelper.refresh(context);
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    private JSONObject fetch(double latitude, double longitude) throws Exception {
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude + "&longitude=" + longitude
                + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,wind_direction_10m"
                + "&timezone=auto&wind_speed_unit=kmh";
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(12000);
        connection.setRequestMethod("GET");
        try {
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new java.io.IOException("Weather HTTP " + code);
            StringBuilder body = new StringBuilder();
            try (InputStream stream = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
            }
            JSONObject current = new JSONObject(body.toString()).getJSONObject("current");
            int codeValue = current.optInt("weather_code", -1);
            int temp = (int) Math.round(current.optDouble("temperature_2m", 0));
            int wind = (int) Math.round(current.optDouble("wind_speed_10m", 0));
            JSONObject out = new JSONObject();
            out.put("temperature", temp);
            out.put("condition", condition(codeValue));
            out.put("wind", wind);
            out.put("windDirection", direction(current.optDouble("wind_direction_10m", Double.NaN)));
            out.put("apparent", (int) Math.round(current.optDouble("apparent_temperature", temp)));
            out.put("humidity", (int) Math.round(current.optDouble("relative_humidity_2m", 0)));
            out.put("summary", condition(codeValue) + " · ветер " + wind + " км/ч");
            return out;
        } finally {
            connection.disconnect();
        }
    }

    private static String direction(double degrees) {
        if (Double.isNaN(degrees)) return "—";
        String[] directions = {"С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"};
        return directions[((int) Math.round(degrees / 45.0)) % 8];
    }

    private static String condition(int code) {
        switch (code) {
            case 0: return "Ясно";
            case 1: return "Преимущественно ясно";
            case 2: return "Переменная облачность";
            case 3: return "Пасмурно";
            case 45: case 48: return "Туман";
            case 51: return "Слабая морось";
            case 53: return "Морось";
            case 55: return "Сильная морось";
            case 61: return "Слабый дождь";
            case 63: return "Дождь";
            case 65: return "Сильный дождь";
            case 71: return "Слабый снег";
            case 73: return "Снег";
            case 75: return "Сильный снег";
            case 80: case 81: return "Ливень";
            case 82: return "Очень сильный ливень";
            case 85: return "Снегопад";
            case 86: return "Сильный снегопад";
            case 95: case 96: case 99: return "Гроза";
            default: return "Погодные условия";
        }
    }
}
