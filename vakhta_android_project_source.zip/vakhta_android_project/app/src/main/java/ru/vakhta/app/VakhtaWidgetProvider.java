package ru.vakhta.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class VakhtaWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }
    static void update(Context context, AppWidgetManager manager, int id) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_small);
        android.appwidget.AppWidgetProviderInfo info = manager.getAppWidgetInfo(id);
        boolean large = info != null && info.minWidth >= 220;
        v = new RemoteViews(context.getPackageName(), large ? R.layout.widget_large : R.layout.widget_small);
        Calendar now = Calendar.getInstance();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now.getTime());
        SharedPreferences prefs = context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        String place = prefs.getString("place", "work");
        v.setTextViewText(R.id.widget_place, place.equals("home") ? "Дом · Ангрен" : "Работа · Матросова");
        v.setTextViewText(R.id.widget_weather, "Погода: — °C");
        v.setTextViewText(R.id.widget_countdown, "Счётчик: открой приложение");
        v.setTextViewText(R.id.widget_week_title, "Неделя · отметки");
        Calendar monday = (Calendar) now.clone();
        int dow = monday.get(Calendar.DAY_OF_WEEK);
        monday.add(Calendar.DAY_OF_MONTH, -(dow == Calendar.SUNDAY ? 6 : dow - Calendar.MONDAY));
        int[] idsDay = {R.id.day0,R.id.day1,R.id.day2,R.id.day3,R.id.day4,R.id.day5,R.id.day6};
        int[] idsLabel = {R.id.label0,R.id.label1,R.id.label2,R.id.label3,R.id.label4,R.id.label5,R.id.label6};
        String[] names = {"Пн","Вт","Ср","Чт","Пт","Сб","Вс"};
        for (int i=0;i<7;i++) {
            Calendar d=(Calendar)monday.clone(); d.add(Calendar.DAY_OF_MONTH,i);
            String key=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d.getTime());
            v.setTextViewText(idsLabel[i], names[i] + " " + d.get(Calendar.DAY_OF_MONTH));
            v.setTextViewText(idsDay[i], prefs.getBoolean("worked_"+key,false) ? "✓" : "○");
            Intent toggle = new Intent(context, VakhtaWidgetProvider.class);
            toggle.setAction("TOGGLE_DAY"); toggle.putExtra("date",key); toggle.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
            v.setOnClickPendingIntent(idsDay[i], PendingIntent.getBroadcast(context, (id*1000+i), toggle, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, pi);
        manager.updateAppWidget(id,v);
    }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context,intent);
        if ("TOGGLE_DAY".equals(intent.getAction())) {
            String date=intent.getStringExtra("date");
            SharedPreferences p=context.getSharedPreferences("vakhta_widget",Context.MODE_PRIVATE);
            p.edit().putBoolean("worked_"+date,!p.getBoolean("worked_"+date,false)).apply();
            AppWidgetManager m=AppWidgetManager.getInstance(context);
            int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
            if(id!=AppWidgetManager.INVALID_APPWIDGET_ID) update(context,m,id);
        }
    }
}
