package ru.vakhta.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import org.json.JSONObject;
import java.util.Iterator;

public class VakhtaWidgetProvider extends AppWidgetProvider {
 @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for(int id:ids) update(c,m,id); }
 static void update(Context c, AppWidgetManager m, int id) {
  android.os.Bundle opts=m.getAppWidgetOptions(id); int width=opts==null?0:opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,0); boolean large=width>=240;
  RemoteViews v=new RemoteViews(c.getPackageName(), large?R.layout.widget_large:R.layout.widget_small);
  Calendar now=Calendar.getInstance(); String today=iso(now); SharedPreferences p=c.getSharedPreferences("vakhta_widget",Context.MODE_PRIVATE);
  String place=p.getString("place", "work"); v.setTextViewText(R.id.widget_place, "home".equals(place)?"Дом · Ангрен":"Работа · Матросова");
  v.setTextViewText(R.id.widget_weather,"Погода · подключим позже");
  String[] period=periodFor(today); String status=period==null?"Дома":"На вахте · "+period[0]; String target=period==null?nextStart(today):period[1];
  int days=target==null?0:Math.max(0,daysBetween(today,target));
  v.setTextViewText(R.id.widget_countdown, target==null?status:status+"\n"+days+" дн. "+(period==null?"до вахты":"до конца"));
  v.setTextViewText(R.id.widget_week_title, large?"Неделя · нажимай день, чтобы отметить ✓":"Ближайшие дни · отметки ✓");
  Calendar monday=(Calendar)now.clone(); int dow=monday.get(Calendar.DAY_OF_WEEK); monday.add(Calendar.DAY_OF_MONTH,-(dow==Calendar.SUNDAY?6:dow-Calendar.MONDAY));
  int[] dayIds={R.id.day0,R.id.day1,R.id.day2,R.id.day3,R.id.day4,R.id.day5,R.id.day6}; int[] labelIds={R.id.label0,R.id.label1,R.id.label2,R.id.label3,R.id.label4,R.id.label5,R.id.label6}; String[] names={"Пн","Вт","Ср","Чт","Пт","Сб","Вс"};
  for(int i=0;i<7;i++){Calendar d=(Calendar)monday.clone();d.add(Calendar.DAY_OF_MONTH,i);String key=iso(d);v.setTextViewText(labelIds[i],names[i]+" "+d.get(Calendar.DAY_OF_MONTH));boolean worked=p.getBoolean("worked_"+key,false);v.setTextViewText(dayIds[i],worked?"✓":"○");Intent t=new Intent(c,VakhtaWidgetProvider.class);t.setAction("TOGGLE_DAY");t.putExtra("date",key);t.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);v.setOnClickPendingIntent(dayIds[i],PendingIntent.getBroadcast(c,id*1000+i,t,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));}
  Intent open=new Intent(c,MainActivity.class);v.setOnClickPendingIntent(R.id.widget_root,PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));m.updateAppWidget(id,v);
 }
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if("TOGGLE_DAY".equals(i.getAction())){String date=i.getStringExtra("date");SharedPreferences p=c.getSharedPreferences("vakhta_widget",Context.MODE_PRIVATE);boolean next=!p.getBoolean("worked_"+date,false);p.edit().putBoolean("worked_"+date,next).putString("widget_override_"+date,next?"1":"0").apply();
  try{JSONObject o=new JSONObject(p.getString("overrides_json","{}"));o.put(date,next);p.edit().putString("overrides_json",o.toString()).apply();}catch(Exception ignored){}
  AppWidgetManager m=AppWidgetManager.getInstance(c);int id=i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);if(id!=AppWidgetManager.INVALID_APPWIDGET_ID)update(c,m,id);}}
 private static String iso(Calendar c){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
 private static int daysBetween(String a,String b){try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);return (int)((f.parse(b).getTime()-f.parse(a).getTime())/86400000L);}catch(Exception e){return 0;}}
 private static String[] periodFor(String s){String[][] ps={{"Ночные смены","2026-10-19","2026-11-18"},{"Дневные смены","2026-11-19","2026-12-18"}};for(int y=2027;y<=2035;y++){String ys=""+y;String[][] add={{"Ночные смены",ys+"-02-19",ys+"-03-18"},{"Дневные смены",ys+"-03-19",ys+"-04-18"},{"Ночные смены",ys+"-06-19",ys+"-07-18"},{"Дневные смены",ys+"-07-19",ys+"-08-18"},{"Ночные смены",ys+"-10-19",ys+"-11-18"},{"Дневные смены",ys+"-11-19",ys+"-12-18"}};for(String[] p:add)if(s.compareTo(p[1])>=0&&s.compareTo(p[2])<=0)return new String[]{p[0],p[2]};}for(String[] p:ps)if(s.compareTo(p[1])>=0&&s.compareTo(p[2])<=0)return new String[]{p[0],p[2]};if(s.compareTo("2026-10-19")<0)return null;return null;}
 private static String nextStart(String s){String[][] candidates={{"2026-11-19","2026-12-18"},{"2027-02-19","2027-03-18"}};for(String[] p:candidates)if(p[0].compareTo(s)>0)return p[0];for(int y=2027;y<=2035;y++){String[] starts={y+"-02-19",y+"-03-19",y+"-06-19",y+"-07-19",y+"-10-19",y+"-11-19"};for(String x:starts)if(x.compareTo(s)>0)return x;}return null;}
}
