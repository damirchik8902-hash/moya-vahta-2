package ru.vakhta.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(20, 30, 42));
        getWindow().setNavigationBarColor(Color.rgb(20, 30, 42));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(20, 30, 42));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new VakhtaBridge(this), "VakhtaBridge");
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    public static class VakhtaBridge {
        private final Context context; private final SharedPreferences prefs;
        VakhtaBridge(Context c) { context=c.getApplicationContext(); prefs=context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE); }
        @JavascriptInterface public String getOverrides() { return prefs.getString("overrides_json", "{}"); }
        @JavascriptInterface public void syncState(String workedJson, String overridesJson, String extrasJson, String location, String periodsJson) {
            prefs.edit().putString("worked_json", workedJson)
                    .putString("overrides_json", overridesJson)
                    .putString("extras_json", extrasJson)
                    .putString("periods_json", periodsJson == null ? "[]" : periodsJson)
                    .putString("place", location == null ? "" : location).apply();
            try { JSONArray a=new JSONArray(workedJson); java.util.HashSet<String> days=new java.util.HashSet<>(); for(int i=0;i<a.length();i++) days.add(a.getString(i));
                SharedPreferences.Editor e=prefs.edit(); java.util.Map<String,?> all=prefs.getAll(); for(String k:all.keySet()) if(k.startsWith("worked_") && k.length()==17) e.remove(k); for(String day:days)e.putBoolean("worked_"+day,true); e.apply();
            } catch(Exception ignored) {}
            AppWidgetManagerHelper.refresh(context);
        }
    }
}
