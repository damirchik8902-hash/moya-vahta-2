package ru.vakhta.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        WeatherRefreshWorker.schedule(this);
        getWindow().setStatusBarColor(Color.rgb(20, 30, 42));
        getWindow().setNavigationBarColor(Color.rgb(20, 30, 42));
        webView = new WebView(this);
        WebView web = webView;
        web.setBackgroundColor(Color.rgb(20, 30, 42));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new VakhtaBridge(this), "VakhtaBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                openForecastFromIntent(getIntent());
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openForecastFromIntent(intent);
    }
    private void openForecastFromIntent(Intent intent) {
        if (intent == null || webView == null) return;
        String kind = intent.getStringExtra("show_weather_forecast");
        if (!"home".equals(kind) && !"work".equals(kind)) return;
        String safeKind = "home".equals(kind) ? "home" : "work";
        webView.evaluateJavascript("if(window.openVakhtaForecast){window.openVakhtaForecast('" + safeKind + "');}", null);
        intent.removeExtra("show_weather_forecast");
    }
    public static class VakhtaBridge {
        private final Context context; private final SharedPreferences prefs;
        VakhtaBridge(Context c) { context=c.getApplicationContext(); prefs=context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE); }
        @JavascriptInterface public String getOverrides() { return prefs.getString("overrides_json", "{}"); }
        @JavascriptInterface public void syncWeather(String weatherJson) {
            try {
                JSONObject incoming = new JSONObject(weatherJson == null ? "{}" : weatherJson);
                AppWidgetManagerHelper.mergeWeatherCache(context, incoming);
            } catch (Exception ignored) { }
            AppWidgetManagerHelper.refresh(context);
        }
        @JavascriptInterface public void syncState(String workedJson, String overridesJson, String extrasJson, String location, String periodsJson) {
            prefs.edit().putString("worked_json", workedJson)
                    .putString("overrides_json", overridesJson)
                    .putString("extras_json", extrasJson)
                    .putString("periods_json", periodsJson == null ? "[]" : periodsJson)
                    .putString("place", location == null ? "" : location).apply();
            try { JSONArray a=new JSONArray(workedJson); java.util.HashSet<String> days=new java.util.HashSet<>(); for(int i=0;i<a.length();i++) days.add(a.getString(i));
                SharedPreferences.Editor e=prefs.edit(); java.util.Map<String,?> all=prefs.getAll(); for(String k:all.keySet()) if(k.startsWith("worked_") && k.length()==17) e.remove(k); for(String day:days)e.putBoolean("worked_"+day,true); e.apply();
            } catch(Exception ignored) {}
            AppWidgetManagerHelper.refresh(context);
        }
    }
}
